﻿using System;
using System.Windows.Forms;
using OracleDBAdmin.UI;

namespace OracleDBAdmin
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new LoginForm());
		}
    }
}