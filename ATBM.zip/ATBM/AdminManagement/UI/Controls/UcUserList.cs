﻿using OracleDBAdmin.Services;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcUserList : UserControl
    {
        private readonly UserService _service = new UserService();

        private TextBox txtSearch;
        private Button btnSearch;
        private Button btnRefresh;
        private Button btnCreate;
        private DataGridView dgv;

        public UcUserList()
        {
            InitializeUi();
			this.Load += (s, e) => LoadData();
		}

        private void InitializeUi()
        {
            BackColor = Color.FromArgb(244, 242, 236);

            var container = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20)
            };

            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 45
            };

            txtSearch = new TextBox { Width = 350, Font = new Font("Segoe UI", 11) };
            btnSearch = new Button { Text = "Tìm", Width = 80, Height = 32 };
            btnRefresh = new Button { Text = "Làm mới", Width = 90, Height = 32 };
            btnCreate = new Button { Text = "+ Tạo mới", Width = 100, Height = 32 };

            btnSearch.Click += (s, e) => SearchData();
            btnRefresh.Click += (s, e) => LoadData();
            btnCreate.Click += (s, e) =>
            {
                var f = new Form { Width = 850, Height = 450, Text = "Tạo User" };
                var uc = new UcUserEditor();
                uc.Dock = DockStyle.Fill;
                f.Controls.Add(uc);
                f.StartPosition = FormStartPosition.CenterParent;
                f.ShowDialog();
                LoadData();
            };

            top.Controls.Add(txtSearch);
            top.Controls.Add(btnSearch);
            top.Controls.Add(btnCreate);
            top.Controls.Add(btnRefresh);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = true,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            dgv.CellContentClick += Dgv_CellContentClick;

            container.Controls.Add(dgv);
            container.Controls.Add(top);

            Controls.Add(container);
        }

		private void LoadData()
		{
			try
			{
				var dt = _service.GetUsers();
				dgv.DataSource = dt;
				AddActionColumns();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Lỗi tải danh sách user: " + ex.Message, "Lỗi Kết Nối",
								MessageBoxButtons.OK, MessageBoxIcon.Error);
				if (this.FindForm() is MainForm main)
				{
					main.IsReturningToLogin = true;
					main.Close();
				}
			}
		}

		private void SearchData()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    LoadData();
                    return;
                }

                var dt = _service.SearchUsers(txtSearch.Text);
                dgv.DataSource = dt;
                AddActionColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tìm user: " + ex.Message);
            }
        }

        private void AddActionColumns()
        {
            if (!dgv.Columns.Contains("EDIT_BTN"))
            {
                var btnEdit = new DataGridViewButtonColumn
                {
                    Name = "EDIT_BTN",
                    HeaderText = "Sửa",
                    Text = "Sửa",
                    UseColumnTextForButtonValue = true,
                    Width = 60
                };
                dgv.Columns.Add(btnEdit);
            }

            if (!dgv.Columns.Contains("DELETE_BTN"))
            {
                var btnDelete = new DataGridViewButtonColumn
                {
                    Name = "DELETE_BTN",
                    HeaderText = "Xóa",
                    Text = "Xóa",
                    UseColumnTextForButtonValue = true,
                    Width = 60
                };
                dgv.Columns.Add(btnDelete);
            }
        }

        private void Dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string username = dgv.Rows[e.RowIndex].Cells["USERNAME"].Value.ToString();

            if (dgv.Columns[e.ColumnIndex].Name == "EDIT_BTN")
            {
                var f = new Form { Width = 850, Height = 450, Text = "Sửa User" };
                var uc = new UcUserEditor(username);
                uc.Dock = DockStyle.Fill;
                f.Controls.Add(uc);
                f.StartPosition = FormStartPosition.CenterParent;
                f.ShowDialog();
                LoadData();
            }
            else if (dgv.Columns[e.ColumnIndex].Name == "DELETE_BTN")
            {
                if (MessageBox.Show($"Xóa user {username}?", "Xác nhận",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        _service.DropUser(username);
                        MessageBox.Show("Xóa user thành công.");
                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi xóa user: " + ex.Message);
                    }
                }
            }
        }
    }
}