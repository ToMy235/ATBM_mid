﻿using OracleDBAdmin.Services;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcRevokePrivilege : UserControl
    {
        private readonly UserService _userService = new UserService();
        private readonly RoleService _roleService = new RoleService();
        private readonly PrivilegeService _service = new PrivilegeService();

        private ComboBox cboType;
        private ComboBox cboName;
        private Button btnLoad;
        private Button btnRevoke;
        private DataGridView dgv;

        public UcRevokePrivilege()
        {
            InitializeUi();
            LoadNames();
        }

        private void InitializeUi()
        {
            BackColor = Color.FromArgb(244, 242, 236);

            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20)
            };

            FlowLayoutPanel top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 45
            };

            cboType = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cboType.Items.AddRange(new object[] { "User", "Role" });
            cboType.SelectedIndex = 0;
            cboType.SelectedIndexChanged += (s, e) => LoadNames();

            cboName = new ComboBox { Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };
            btnLoad = new Button { Text = "Tải danh sách quyền", Width = 160, Height = 32 };
            btnRevoke = new Button { Text = "Thu hồi đã chọn", Width = 140, Height = 32 };

            btnLoad.Click += (s, e) => LoadPrivileges();
            btnRevoke.Click += BtnRevoke_Click;

            top.Controls.Add(cboType);
            top.Controls.Add(cboName);
            top.Controls.Add(btnLoad);
            top.Controls.Add(btnRevoke);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = true,
                AllowUserToAddRows = false,
                ReadOnly = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            card.Controls.Add(dgv);
            card.Controls.Add(top);
            Controls.Add(card);
        }

        private void LoadNames()
        {
            if (cboType.SelectedItem?.ToString() == "User")
            {
                var dt = _userService.GetAllUsersForCombo();
                cboName.DataSource = dt;
                cboName.DisplayMember = "USERNAME";
                cboName.ValueMember = "USERNAME";
            }
            else
            {
                var dt = _roleService.GetAllRolesForCombo();
                cboName.DataSource = dt;
                cboName.DisplayMember = "ROLE";
                cboName.ValueMember = "ROLE";
            }
        }

        private void LoadPrivileges()
        {
            try
            {
                string grantee = cboName.SelectedValue?.ToString();
                var dt = _service.GetPrivilegeListForRevoke(grantee);
                dgv.DataSource = dt;

                if (!dgv.Columns.Contains("CHK"))
                {
                    DataGridViewCheckBoxColumn chk = new DataGridViewCheckBoxColumn
                    {
                        Name = "CHK",
                        HeaderText = "Chọn"
                    };
                    dgv.Columns.Insert(0, chk);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách quyền: " + ex.Message);
            }
        }

        private void BtnRevoke_Click(object sender, EventArgs e)
        {
            try
            {
                string grantee = cboName.SelectedValue?.ToString();
                if (string.IsNullOrWhiteSpace(grantee))
                {
                    MessageBox.Show("Chưa chọn user/role.");
                    return;
                }

                int count = 0;
                foreach (DataGridViewRow row in dgv.Rows)
                {
                    bool selected = row.Cells["CHK"].Value != null && Convert.ToBoolean(row.Cells["CHK"].Value);
                    if (!selected) continue;

                    string category = row.Cells["CATEGORY"].Value?.ToString();
                    string priv = row.Cells["PRIVILEGE"].Value?.ToString();

                    if (category == "SYSTEM")
                    {
                        _service.RevokeSystemPrivilege(priv, grantee);
                    }
                    else if (category == "ROLE")
                    {
                        _service.RevokeRole(priv, grantee);
                    }
                    else
                    {
                        string owner = row.Cells["OWNER"].Value?.ToString();
                        string obj = row.Cells["OBJECT_NAME"].Value?.ToString();
                        _service.RevokeObjectPrivilege(priv, owner, obj, grantee);
                    }

                    count++;
                }

                MessageBox.Show(count > 0 ? "Thu hồi quyền thành công." : "Chưa chọn dòng nào.");
                LoadPrivileges();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi REVOKE: " + ex.Message);
            }
        }
    }
}