﻿using OracleDBAdmin.Services;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcUserEditor : UserControl
    {
        private readonly UserService _service = new UserService();
        private readonly string _editingUsername;

        private TextBox txtUsername;
        private TextBox txtPassword;
        private TextBox txtConfirmPassword;
        private ComboBox cboProfile;
        private ComboBox cboDefaultTs;
        private ComboBox cboTempTs;
        private ComboBox cboStatus;
        private DateTimePicker dtpExpiry;
        private CheckBox chkUseExpiry;
        private Button btnSave;
        private Button btnCancel;

        public UcUserEditor(string editingUsername = null)
        {
            _editingUsername = editingUsername;
            InitializeUi();
            LoadCombos();

            if (!string.IsNullOrWhiteSpace(_editingUsername))
                LoadUserInfo();
        }

        private void InitializeUi()
        {
            BackColor = Color.FromArgb(244, 242, 236);

            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20)
            };

            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 2,
                RowCount = 8
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            txtUsername = new TextBox { Font = new Font("Segoe UI", 11), Width = 300 };
            txtPassword = new TextBox { Font = new Font("Segoe UI", 11), Width = 300, UseSystemPasswordChar = true };
            txtConfirmPassword = new TextBox { Font = new Font("Segoe UI", 11), Width = 300, UseSystemPasswordChar = true };
            cboProfile = new ComboBox { Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            cboDefaultTs = new ComboBox { Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            cboTempTs = new ComboBox { Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            cboStatus = new ComboBox { Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            cboStatus.Items.AddRange(new object[] { "UNLOCK", "LOCK" });
            cboStatus.SelectedIndex = 0;

            dtpExpiry = new DateTimePicker
            {
                Width = 300,
                Format = DateTimePickerFormat.Short
            };

            chkUseExpiry = new CheckBox
            {
                Text = "Đánh dấu password expire",
                AutoSize = true
            };

            btnSave = new Button { Text = "Lưu", Width = 100, Height = 35 };
            btnCancel = new Button { Text = "Hủy", Width = 100, Height = 35 };

            btnSave.Click += BtnSave_Click;
            btnCancel.Click += (s, e) => FindForm()?.Close();

            AddRow(layout, "Username *", txtUsername, "Mật khẩu *", txtPassword);
            AddRow(layout, "Confirm mật khẩu *", txtConfirmPassword, "Profile", cboProfile);
            AddRow(layout, "Default Tablespace", cboDefaultTs, "Temp Tablespace", cboTempTs);
            AddRow(layout, "Trạng thái tài khoản", cboStatus, "Ngày hết hạn mật khẩu", dtpExpiry);

            FlowLayoutPanel bottom = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                FlowDirection = FlowDirection.RightToLeft
            };
            bottom.Controls.Add(btnSave);
            bottom.Controls.Add(btnCancel);

            card.Controls.Add(bottom);
            card.Controls.Add(chkUseExpiry);
            chkUseExpiry.Top = 260;
            chkUseExpiry.Left = 20;

            card.Controls.Add(layout);
            Controls.Add(card);
        }

        private void AddRow(TableLayoutPanel layout, string label1, Control c1, string label2, Control c2)
        {
            layout.Controls.Add(new Label { Text = label1, AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            layout.Controls.Add(new Label { Text = label2, AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            layout.Controls.Add(c1);
            layout.Controls.Add(c2);
        }

        private void LoadCombos()
        {
            var profiles = _service.GetProfiles();
            cboProfile.DataSource = profiles;
            cboProfile.DisplayMember = "PROFILE";
            cboProfile.ValueMember = "PROFILE";

            var ts = _service.GetTablespaces();
            cboDefaultTs.DataSource = ts.Copy();
            cboDefaultTs.DisplayMember = "TABLESPACE_NAME";
            cboDefaultTs.ValueMember = "TABLESPACE_NAME";

            cboTempTs.DataSource = ts;
            cboTempTs.DisplayMember = "TABLESPACE_NAME";
            cboTempTs.ValueMember = "TABLESPACE_NAME";
        }

        private void LoadUserInfo()
        {
            var row = _service.GetUserByName(_editingUsername);
            if (row == null) return;

            txtUsername.Text = row["USERNAME"].ToString();
            txtUsername.Enabled = false;
            cboDefaultTs.SelectedValue = row["DEFAULT_TABLESPACE"].ToString();
            cboTempTs.SelectedValue = row["TEMPORARY_TABLESPACE"].ToString();
            cboProfile.SelectedValue = row["PROFILE"].ToString();
            cboStatus.SelectedItem = row["ACCOUNT_STATUS"].ToString().Contains("LOCK") ? "LOCK" : "UNLOCK";
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUsername.Text.Trim();
                string password = txtPassword.Text;
                string confirm = txtConfirmPassword.Text;
                string profile = cboProfile.SelectedValue?.ToString();
                string defaultTs = cboDefaultTs.SelectedValue?.ToString();
                string tempTs = cboTempTs.SelectedValue?.ToString();
                bool unlock = cboStatus.SelectedItem?.ToString() == "UNLOCK";

                if (string.IsNullOrWhiteSpace(username))
                {
                    MessageBox.Show("Username không được rỗng.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(_editingUsername))
                {
                    if (string.IsNullOrWhiteSpace(password))
                    {
                        MessageBox.Show("Mật khẩu không được rỗng.");
                        return;
                    }

                    if (password != confirm)
                    {
                        MessageBox.Show("Confirm mật khẩu không khớp.");
                        return;
                    }

                    _service.CreateUser(
                        username,
                        password,
                        defaultTs,
                        tempTs,
                        profile,
                        unlock,
                        chkUseExpiry.Checked ? dtpExpiry.Value : (DateTime?)null);

                    MessageBox.Show("Tạo user thành công.");
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(password) || !string.IsNullOrWhiteSpace(confirm))
                    {
                        if (password != confirm)
                        {
                            MessageBox.Show("Confirm mật khẩu không khớp.");
                            return;
                        }
                    }

                    _service.AlterUser(
                        username,
                        password,
                        defaultTs,
                        tempTs,
                        profile,
                        unlock);

                    MessageBox.Show("Cập nhật user thành công.");
                }

               // FindForm()?.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lưu user: " + ex.Message);
            }
        }
    }
}