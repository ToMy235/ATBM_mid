﻿using OracleDBAdmin.Services;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcGrantPrivilege : UserControl
    {
        private readonly UserService _userService = new UserService();
        private readonly RoleService _roleService = new RoleService();
        private readonly PrivilegeService _service = new PrivilegeService();

        private ComboBox cboTargetType;
        private ComboBox cboTargetName;
        private ComboBox cboGrantType;

        private ComboBox cboObjectType;
        private ComboBox cboSchema;
        private ComboBox cboObjectName;
        private ComboBox cboPrivilege;
        private ComboBox cboRole;

        private CheckedListBox clbColumns;
        private CheckBox chkAdminOption;
        private CheckBox chkGrantOption;
        private Button btnExecute;

        private Panel card;
        private Label lblTitle;
        private Label lblHint;

        private readonly Color BgColor = Color.FromArgb(240, 249, 255);
        private readonly Color SurfaceColor = Color.White;
        private readonly Color PrimaryColor = Color.FromArgb(37, 99, 235);
        private readonly Color PrimaryHoverColor = Color.FromArgb(29, 78, 216);
        private readonly Color BorderColor = Color.FromArgb(186, 230, 253);
        private readonly Color TextColor = Color.FromArgb(15, 23, 42);
        private readonly Color HintBgColor = Color.FromArgb(224, 242, 254);
        private readonly Color MutedTextColor = Color.FromArgb(100, 116, 139);
        public UcGrantPrivilege()
        {
            InitializeUi();
            LoadBaseData();
            RefreshVisibleState();
        }

        private void InitializeUi()
        {
            SuspendLayout();

            BackColor = BgColor;
            Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            Padding = new Padding(18);

            card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = SurfaceColor,
                Padding = new Padding(24)
            };

            lblTitle = new Label
            {
                Text = "Cấp quyền (Grant Privileges)",
                AutoSize = true,
                Font = new Font("Segoe UI", 14F, FontStyle.Bold),
                ForeColor = TextColor,
                Location = new Point(0, 0)
            };

            lblHint = new Label
            {
                Text = "Chọn đối tượng nhận quyền, loại quyền và cấu hình chi tiết trước khi thực hiện GRANT.",
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Regular),
                ForeColor = MutedTextColor,
                Location = new Point(0, 34)
            };

            var headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 66
            };
            headerPanel.Controls.Add(lblTitle);
            headerPanel.Controls.Add(lblHint);

            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 3,
                Padding = new Padding(0, 8, 0, 0)
            };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));

            cboTargetType = CreateComboBox();
            cboTargetType.Items.AddRange(new object[] { "User", "Role" });
            cboTargetType.SelectedIndex = 0;

            cboTargetName = CreateComboBox();
            cboGrantType = CreateComboBox();
            cboGrantType.Items.AddRange(new object[] { "System Privilege", "Object Privilege", "Role" });
            cboGrantType.SelectedIndex = 0;

            cboObjectType = CreateComboBox();
            cboObjectType.Items.AddRange(new object[] { "TABLE", "VIEW", "PROCEDURE", "FUNCTION" });

            cboSchema = CreateComboBox();
            cboObjectName = CreateComboBox();
            cboPrivilege = CreateComboBox();
            cboRole = CreateComboBox();

            AddField(mainLayout, "Đối tượng được cấp", cboTargetType, 0, 0);
            AddField(mainLayout, "Tên User/Role", cboTargetName, 1, 0);
            AddField(mainLayout, "Loại quyền", cboGrantType, 2, 0);

            AddField(mainLayout, "Loại đối tượng", cboObjectType, 0, 2);
            AddField(mainLayout, "Schema", cboSchema, 1, 2);
            AddField(mainLayout, "Tên đối tượng", cboObjectName, 2, 2);

            AddField(mainLayout, "Privilege", cboPrivilege, 0, 4);
            AddField(mainLayout, "Role", cboRole, 1, 4);

            var emptyPanel = new Panel { Dock = DockStyle.Fill, Margin = new Padding(8, 0, 8, 0) };
            mainLayout.Controls.Add(emptyPanel, 2, 5);

            var colCard = new Panel
            {
                Dock = DockStyle.Top,
                Height = 190,
                Padding = new Padding(16),
                Margin = new Padding(0, 18, 0, 0),
                BackColor = SurfaceColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            var lbCol = new Label
            {
                Text = "Chọn cột (áp dụng cho SELECT/UPDATE)",
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = TextColor,
                Location = new Point(16, 14)
            };

            var lbColHint = new Label
            {
                Text = "Nếu không chọn cột, quyền sẽ áp dụng theo cấu hình hiện tại của câu GRANT.",
                AutoSize = true,
                Font = new Font("Segoe UI", 9F, FontStyle.Regular),
                ForeColor = MutedTextColor,
                Location = new Point(16, 38)
            };

            clbColumns = new CheckedListBox
            {
                Location = new Point(16, 68),
                Size = new Size(520, 98),
                Font = new Font("Segoe UI", 10F),
                BorderStyle = BorderStyle.FixedSingle,
                CheckOnClick = true
            };

            colCard.Controls.Add(lbCol);
            colCard.Controls.Add(lbColHint);
            colCard.Controls.Add(clbColumns);

            var optionsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 42,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 12, 0, 0),
                Margin = new Padding(0)
            };

            chkAdminOption = new CheckBox
            {
                Text = "WITH ADMIN OPTION",
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = TextColor,
                Margin = new Padding(0, 3, 22, 0)
            };

            chkGrantOption = new CheckBox
            {
                Text = "WITH GRANT OPTION",
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = TextColor,
                Margin = new Padding(0, 3, 22, 0)
            };

            optionsPanel.Controls.Add(chkAdminOption);
            optionsPanel.Controls.Add(chkGrantOption);

            var infoBox = new Label
            {
                Dock = DockStyle.Top,
                Height = 48,
                BackColor = HintBgColor,
                BorderStyle = BorderStyle.FixedSingle,
                Text = "  Gợi ý: System privilege và role dùng WITH ADMIN OPTION. Object privilege dùng WITH GRANT OPTION.",
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Regular),
                ForeColor = PrimaryColor,
                Margin = new Padding(0, 12, 0, 0)
            };

            var bottomPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 64,
                Padding = new Padding(0, 16, 0, 0)
            };

            btnExecute = CreatePrimaryButton("Thực hiện GRANT");
            btnExecute.Size = new Size(180, 40);
            btnExecute.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            btnExecute.Location = new Point(bottomPanel.Width - btnExecute.Width, 16);
            btnExecute.Click += BtnExecute_Click;
            bottomPanel.Resize += (s, e) =>
            {
                btnExecute.Left = bottomPanel.ClientSize.Width - btnExecute.Width;
            };
            bottomPanel.Controls.Add(btnExecute);

            cboTargetType.SelectedIndexChanged += (s, e) => LoadTargetNames();
            cboGrantType.SelectedIndexChanged += (s, e) => RefreshVisibleState();
            cboObjectType.SelectedIndexChanged += (s, e) =>
            {
                LoadObjectNames();
                FillObjectPrivileges();
            };
            cboSchema.SelectedIndexChanged += (s, e) => LoadObjectNames();
            cboObjectName.SelectedIndexChanged += (s, e) => LoadColumns();
            cboPrivilege.SelectedIndexChanged += (s, e) => RefreshVisibleState();

            card.Controls.Add(bottomPanel);
            card.Controls.Add(infoBox);
            card.Controls.Add(optionsPanel);
            card.Controls.Add(colCard);
            card.Controls.Add(mainLayout);
            card.Controls.Add(headerPanel);

            Controls.Clear();
            Controls.Add(card);

            ResumeLayout(false);
        }

        private ComboBox CreateComboBox()
        {
            return new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Height = 36,
                Font = new Font("Segoe UI", 10F),
                BackColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(8, 0, 8, 0)
            };
        }

        private Button CreatePrimaryButton(string text)
        {
            var btn = new Button
            {
                Text = text,
                FlatStyle = FlatStyle.Flat,
                BackColor = PrimaryColor,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.MouseEnter += (s, e) => btn.BackColor = PrimaryHoverColor;
            btn.MouseLeave += (s, e) => btn.BackColor = PrimaryColor;

            return btn;
        }

        private void AddField(TableLayoutPanel layout, string labelText, Control input, int col, int rowBase)
        {
            EnsureRow(layout, rowBase);
            EnsureRow(layout, rowBase + 1);

            var lbl = new Label
            {
                Text = labelText,
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = TextColor,
                Margin = new Padding(8, 0, 8, 6)
            };

            input.Margin = new Padding(8, 0, 8, 16);

            layout.Controls.Add(lbl, col, rowBase);
            layout.Controls.Add(input, col, rowBase + 1);
        }

        private void EnsureRow(TableLayoutPanel layout, int rowIndex)
        {
            while (layout.RowCount <= rowIndex)
            {
                layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                layout.RowCount++;
            }
        }

        private void LoadBaseData()
        {
            LoadTargetNames();

            var schemas = _service.GetSchemas();
            cboSchema.DataSource = schemas;
            cboSchema.DisplayMember = "USERNAME";
            cboSchema.ValueMember = "USERNAME";

            var roles = _roleService.GetAllRolesForCombo();
            cboRole.DataSource = roles;
            cboRole.DisplayMember = "ROLE";
            cboRole.ValueMember = "ROLE";

            cboObjectType.SelectedIndex = 0;
            LoadObjectNames();
            FillSystemPrivileges();
        }

        private void LoadTargetNames()
        {
            if (cboTargetType.SelectedItem?.ToString() == "User")
            {
                var dt = _userService.GetAllUsersForCombo();
                cboTargetName.DataSource = dt;
                cboTargetName.DisplayMember = "USERNAME";
                cboTargetName.ValueMember = "USERNAME";
            }
            else
            {
                var dt = _roleService.GetAllRolesForCombo();
                cboTargetName.DataSource = dt;
                cboTargetName.DisplayMember = "ROLE";
                cboTargetName.ValueMember = "ROLE";
            }
        }

        private void FillSystemPrivileges()
        {
            cboPrivilege.DataSource = _service.GetCommonSystemPrivileges()
                .Select(x => new { NAME = x })
                .ToList();
            cboPrivilege.DisplayMember = "NAME";
            cboPrivilege.ValueMember = "NAME";
        }

        private void FillObjectPrivileges()
        {
            string type = cboObjectType.SelectedItem?.ToString() ?? "TABLE";
            string[] items;

            if (type == "TABLE" || type == "VIEW")
                items = new[] { "SELECT", "INSERT", "UPDATE", "DELETE", "REFERENCES", "ALTER", "INDEX" };
            else
                items = new[] { "EXECUTE" };

            cboPrivilege.DataSource = items.Select(x => new { NAME = x }).ToList();
            cboPrivilege.DisplayMember = "NAME";
            cboPrivilege.ValueMember = "NAME";
        }

        private void LoadObjectNames()
        {
            if (cboSchema.SelectedValue == null || cboObjectType.SelectedItem == null)
                return;

            var dt = _service.GetObjectsByType(
                cboSchema.SelectedValue.ToString(),
                cboObjectType.SelectedItem.ToString());

            cboObjectName.DataSource = dt;
            cboObjectName.DisplayMember = "OBJECT_NAME";
            cboObjectName.ValueMember = "OBJECT_NAME";
        }

        private void LoadColumns()
        {
            clbColumns.Items.Clear();

            if (cboSchema.SelectedValue == null || cboObjectName.SelectedValue == null)
                return;

            string type = cboObjectType.SelectedItem?.ToString();
            if (type != "TABLE" && type != "VIEW")
                return;

            var dt = _service.GetColumns(
                cboSchema.SelectedValue.ToString(),
                cboObjectName.SelectedValue.ToString());

            foreach (DataRow row in dt.Rows)
                clbColumns.Items.Add(row["COLUMN_NAME"].ToString());
        }

        private void RefreshVisibleState()
        {
            string grantType = cboGrantType.SelectedItem?.ToString() ?? "";
            string privilege = cboPrivilege.Text;

            bool isObject = grantType == "Object Privilege";
            bool isRole = grantType == "Role";
            bool isSystem = grantType == "System Privilege";

            cboObjectType.Enabled = isObject;
            cboSchema.Enabled = isObject;
            cboObjectName.Enabled = isObject;

            cboRole.Enabled = isRole;
            cboPrivilege.Enabled = !isRole;

            chkAdminOption.Visible = isRole || isSystem;
            chkGrantOption.Visible = isObject;

            clbColumns.Enabled = isObject && (privilege == "SELECT" || privilege == "UPDATE");
        }

        private void BtnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                string target = cboTargetName.SelectedValue?.ToString();
                string grantType = cboGrantType.SelectedItem?.ToString();

                if (string.IsNullOrWhiteSpace(target))
                {
                    MessageBox.Show("Chưa chọn user/role nhận quyền.");
                    return;
                }

                if (grantType == "System Privilege")
                {
                    string privilege = cboPrivilege.SelectedValue?.ToString();
                    _service.GrantSystemPrivilege(privilege, target, chkAdminOption.Checked);
                }
                else if (grantType == "Role")
                {
                    string role = cboRole.SelectedValue?.ToString();
                    _service.GrantRole(role, target, chkAdminOption.Checked);
                }
                else
                {
                    string privilege = cboPrivilege.SelectedValue?.ToString();
                    string owner = cboSchema.SelectedValue?.ToString();
                    string objectName = cboObjectName.SelectedValue?.ToString();
                    string[] cols = clbColumns.CheckedItems.Cast<string>().ToArray();

                    _service.GrantObjectPrivilege(
                        privilege,
                        owner,
                        objectName,
                        target,
                        cols,
                        chkGrantOption.Checked);
                }

                MessageBox.Show("Cấp quyền thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi GRANT: " + ex.Message);
            }
        }
    }
}