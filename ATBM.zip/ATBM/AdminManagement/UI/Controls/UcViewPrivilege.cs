﻿using OracleDBAdmin.Services;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcViewPrivilege : UserControl
    {
        private readonly UserService _userService = new UserService();
        private readonly RoleService _roleService = new RoleService();
        private readonly PrivilegeService _service = new PrivilegeService();

        private ComboBox cboType;
        private ComboBox cboName;
        private Button btnView;

        private DataGridView dgvObject;
        private DataGridView dgvSystem;
        private DataGridView dgvRole;

        public UcViewPrivilege()
        {
            InitializeUi();
            LoadNames();
        }

        private void InitializeUi()
        {
            BackColor = Color.FromArgb(244, 242, 236);

            Panel root = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20)
            };

            FlowLayoutPanel top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 45
            };

            cboType = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cboType.Items.AddRange(new object[] { "User", "Role" });
            cboType.SelectedIndex = 0;
            cboType.SelectedIndexChanged += (s, e) => LoadNames();

            cboName = new ComboBox { Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };
            btnView = new Button { Text = "Xem quyền", Width = 120, Height = 32 };
            btnView.Click += BtnView_Click;

            top.Controls.Add(cboType);
            top.Controls.Add(cboName);
            top.Controls.Add(btnView);

            var lbl1 = new Label { Text = "Quyền đối tượng (Object Privileges)", Dock = DockStyle.Top, Height = 30, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            dgvObject = CreateGrid();

            var lbl2 = new Label { Text = "Quyền hệ thống (System Privileges)", Dock = DockStyle.Top, Height = 30, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            dgvSystem = CreateGrid();

            var lbl3 = new Label { Text = "Roles", Dock = DockStyle.Top, Height = 30, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            dgvRole = CreateGrid();

            var panel3 = new Panel { Dock = DockStyle.Fill };
            panel3.Controls.Add(dgvRole);
            panel3.Controls.Add(lbl3);

            var panel2 = new Panel { Dock = DockStyle.Bottom, Height = 180 };
            panel2.Controls.Add(dgvSystem);
            panel2.Controls.Add(lbl2);

            var panel1 = new Panel { Dock = DockStyle.Bottom, Height = 250 };
            panel1.Controls.Add(dgvObject);
            panel1.Controls.Add(lbl1);

            root.Controls.Add(panel3);
            root.Controls.Add(panel2);
            root.Controls.Add(panel1);
            root.Controls.Add(top);

            Controls.Add(root);
        }

        private DataGridView CreateGrid()
        {
            return new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = true,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
        }

        private void LoadNames()
        {
            if (cboType.SelectedItem?.ToString() == "User")
            {
                var dt = _userService.GetAllUsersForCombo();
                cboName.DataSource = dt;
                cboName.DisplayMember = "USERNAME";
                cboName.ValueMember = "USERNAME";
            }
            else
            {
                var dt = _roleService.GetAllRolesForCombo();
                cboName.DataSource = dt;
                cboName.DisplayMember = "ROLE";
                cboName.ValueMember = "ROLE";
            }
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            try
            {
                string grantee = cboName.SelectedValue?.ToString();
                dgvObject.DataSource = _service.GetObjectPrivileges(grantee);
                dgvSystem.DataSource = _service.GetSystemPrivileges(grantee);
                dgvRole.DataSource = _service.GetRolePrivileges(grantee);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xem quyền: " + ex.Message);
            }
        }
    }
}