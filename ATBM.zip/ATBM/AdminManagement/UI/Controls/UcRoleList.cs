﻿using OracleDBAdmin.Services;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcRoleList : UserControl
    {
        private readonly RoleService _service = new RoleService();

        private TextBox txtSearch;
        private Button btnSearch;
        private Button btnRefresh;
        private Button btnCreate;
        private DataGridView dgv;

        public UcRoleList()
        {
            InitializeUi();
            LoadData();
        }

        private void InitializeUi()
        {
            BackColor = Color.FromArgb(244, 242, 236);

            var container = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20)
            };

            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 45
            };

            txtSearch = new TextBox { Width = 350, Font = new Font("Segoe UI", 11) };
            btnSearch = new Button { Text = "Tìm", Width = 80, Height = 32 };
            btnRefresh = new Button { Text = "Làm mới", Width = 90, Height = 32 };
            btnCreate = new Button { Text = "+ Tạo mới", Width = 100, Height = 32 };

            btnSearch.Click += (s, e) => SearchData();
            btnRefresh.Click += (s, e) => LoadData();
            btnCreate.Click += (s, e) =>
            {
                var f = new Form { Width = 750, Height = 300, Text = "Tạo Role" };
                var uc = new UcRoleEditor();
                uc.Dock = DockStyle.Fill;
                f.Controls.Add(uc);
                f.StartPosition = FormStartPosition.CenterParent;
                f.ShowDialog();
                LoadData();
            };

            top.Controls.Add(txtSearch);
            top.Controls.Add(btnSearch);
            top.Controls.Add(btnCreate);
            top.Controls.Add(btnRefresh);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = true,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            dgv.CellContentClick += Dgv_CellContentClick;

            container.Controls.Add(dgv);
            container.Controls.Add(top);
            Controls.Add(container);
        }

        private void LoadData()
        {
            try
            {
                dgv.DataSource = _service.GetRoles();
                AddActionColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải role: " + ex.Message);
            }
        }

        private void SearchData()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    LoadData();
                    return;
                }

                dgv.DataSource = _service.SearchRoles(txtSearch.Text);
                AddActionColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tìm role: " + ex.Message);
            }
        }

        private void AddActionColumns()
        {
            if (!dgv.Columns.Contains("EDIT_BTN"))
            {
                dgv.Columns.Add(new DataGridViewButtonColumn
                {
                    Name = "EDIT_BTN",
                    HeaderText = "Sửa",
                    Text = "Sửa",
                    UseColumnTextForButtonValue = true
                });
            }

            if (!dgv.Columns.Contains("DELETE_BTN"))
            {
                dgv.Columns.Add(new DataGridViewButtonColumn
                {
                    Name = "DELETE_BTN",
                    HeaderText = "Xóa",
                    Text = "Xóa",
                    UseColumnTextForButtonValue = true
                });
            }
        }

        private void Dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string role = dgv.Rows[e.RowIndex].Cells["ROLE"].Value.ToString();

            if (dgv.Columns[e.ColumnIndex].Name == "EDIT_BTN")
            {
                var f = new Form { Width = 750, Height = 300, Text = "Sửa Role" };
                var uc = new UcRoleEditor(role);
                uc.Dock = DockStyle.Fill;
                f.Controls.Add(uc);
                f.StartPosition = FormStartPosition.CenterParent;
                f.ShowDialog();
                LoadData();
            }
            else if (dgv.Columns[e.ColumnIndex].Name == "DELETE_BTN")
            {
                if (MessageBox.Show($"Xóa role {role}?", "Xác nhận",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        _service.DropRole(role);
                        MessageBox.Show("Xóa role thành công.");
                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi xóa role: " + ex.Message);
                    }
                }
            }
        }
    }
}