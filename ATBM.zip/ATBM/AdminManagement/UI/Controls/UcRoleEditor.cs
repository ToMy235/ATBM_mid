﻿using OracleDBAdmin.Services;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace OracleDBAdmin.UI.Controls
{
    public class UcRoleEditor : UserControl
    {
        private readonly RoleService _service = new RoleService();
        private readonly string _editingRole;

        private TextBox txtRoleName;
        private ComboBox cboAuth;
        private TextBox txtPassword;
        private Button btnSave;
        private Button btnCancel;

        public UcRoleEditor(string editingRole = null)
        {
            _editingRole = editingRole;
            InitializeUi();

            if (!string.IsNullOrWhiteSpace(_editingRole))
                LoadRole();
        }

        private void InitializeUi()
        {
            BackColor = Color.FromArgb(244, 242, 236);

            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20)
            };

            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 2
            };

            txtRoleName = new TextBox { Width = 300, Font = new Font("Segoe UI", 11) };
            cboAuth = new ComboBox { Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };
            cboAuth.Items.AddRange(new object[] { "NONE", "PASSWORD" });
            cboAuth.SelectedIndex = 0;
            txtPassword = new TextBox { Width = 300, Font = new Font("Segoe UI", 11), UseSystemPasswordChar = true, Enabled = false };

            cboAuth.SelectedIndexChanged += (s, e) =>
            {
                txtPassword.Enabled = cboAuth.SelectedItem?.ToString() == "PASSWORD";
            };

            btnSave = new Button { Text = "Lưu", Width = 100, Height = 35 };
            btnCancel = new Button { Text = "Hủy", Width = 100, Height = 35 };

            btnSave.Click += BtnSave_Click;
            btnCancel.Click += (s, e) => FindForm()?.Close();

            layout.Controls.Add(new Label { Text = "Role Name *", AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            layout.Controls.Add(new Label { Text = "Authentication", AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            layout.Controls.Add(txtRoleName);
            layout.Controls.Add(cboAuth);

            layout.Controls.Add(new Label { Text = "Password", AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            layout.Controls.Add(new Label());
            layout.Controls.Add(txtPassword);
            layout.Controls.Add(new Label());

            FlowLayoutPanel bottom = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                FlowDirection = FlowDirection.RightToLeft
            };
            bottom.Controls.Add(btnSave);
            bottom.Controls.Add(btnCancel);

            card.Controls.Add(bottom);
            card.Controls.Add(layout);

            Controls.Add(card);
        }

        private void LoadRole()
        {
            var row = _service.GetRoleByName(_editingRole);
            if (row == null) return;

            txtRoleName.Text = row["ROLE"].ToString();
            txtRoleName.Enabled = false;

            string passwordRequired = row["PASSWORD_REQUIRED"].ToString();
            cboAuth.SelectedItem = passwordRequired == "YES" ? "PASSWORD" : "NONE";
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string roleName = txtRoleName.Text.Trim();
                string auth = cboAuth.SelectedItem?.ToString();
                string password = txtPassword.Text;

                if (string.IsNullOrWhiteSpace(roleName))
                {
                    MessageBox.Show("Role name không được rỗng.");
                    return;
                }

                if (auth == "PASSWORD" && string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Role kiểu PASSWORD phải nhập mật khẩu.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(_editingRole))
                {
                    _service.CreateRole(roleName, auth, password);
                    MessageBox.Show("Tạo role thành công.");
                }
                else
                {
                    _service.AlterRole(roleName, auth, password);
                    MessageBox.Show("Cập nhật role thành công.");
                }

               // FindForm()?.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lưu role: " + ex.Message);
            }
        }
    }
}